#include "parser.h"

#include <iostream>

typedef ProductionBuilder PB;

void emit(char c)
{
    std::cout << c << std::endl;
}

int main(int argc, char *argv[])
{
    GM_BEGIN(PL);
    GM_ADD(PL, start);
    GM_ADD(PL, expr);
    GM_ADD(PL, term);
    GM_ADD(PL, fact);

    start =
        PB::PROD(expr);
    expr =
        PB::AND(
            PB::PROD(term),
            PB::REP(
                PB::AND(
                    PB::SYM('*'),
                    PB::PROD(term),
                    PB::CODE([]{ emit('*'); }))));
    term =
        PB::AND(
            PB::PROD(fact),
            PB::REP(
                PB::AND(
                    PB::SYM('+'),
                    PB::PROD(fact),
                    PB::CODE([]{ emit('+'); }))));
    fact =
        PB::AND(
            PB::SYM('1'),
            PB::CODE([]{ emit('1'); }));

    GM_END(PL);
    return 0;
}