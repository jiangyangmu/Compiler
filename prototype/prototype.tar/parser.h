#pragma once

#include "lexer.h"
#include "util.h"

#include <deque>
#include <list>
#include <set>
#include <string>
#include <utility>
#include <vector>

class ProductionList;

class Production {
    friend class ProductionBuilder;
public:
    enum Type { SYM, CODE, PROD, AND, OR, OPT, REP };
    // iterate production tree in preorder
    class iterator {
            friend class Production;
        public:
            iterator & operator++();
            Production & operator*();
            bool operator==(const iterator &other) const;
            bool operator!=(const iterator &other) const;
        private:
            explicit iterator();
            explicit iterator(Production &root);
            std::deque<Production*> next_;
    };
private:
// fields
    std::string name_;
    // type {SYM, CODE, PROD, AND, OR, OPT, REP}
    Type type_;
    // data for all types
    union {
        Token *symbol_; // SYM
        std::function<void()> *code_; // CODE
        Production *production_; // PROD
        ProductionList *children_; // AND, OR
        Production *child_; // OPT, REP
        void *data_;
    };
    // FIRST,FOLLOW for all types (except CODE)
    TokenSet FIRST_;
    TokenSet FOLLOW_;
public:
    // Production() {}
    // Production(std::string name, Type type)
    //     : name_(name), type_(type), data_(nullptr) {}
    // Production(Production &&p)
    //     : name_(std::move(p.name_)), type_(p.type_), data_(p.data_),
    //       FIRST_(std::move(p.FIRST_)), FOLLOW_(std::move(p.FOLLOW_)) {}
    // void operator=(Production &p) {
    //     production_ = &p;
    // }
    // void operator=(Production &&p) {
    //     production_ = new Production(std::move(p));
    // }
// methods
    std::string name() const { return name_; }
    Type type() const { return type_; }
    Token & symbol();
    std::function<void()> & code();
    Production & production();
    ProductionList & children();
    Production & child();
    TokenSet & FIRST();
    TokenSet & FOLLOW();
    bool is(Type type) { return type_ == type; }
    // iterate production tree, only for PROD
    iterator begin();
    iterator end();
// for testing
    std::string DebugString();
};

class ProductionList : private std::deque<Production *> {
public:
    class adjacent_iterator {
        friend class ProductionList;
    public:
        adjacent_iterator & operator++();
        std::pair<Production &, Production &> operator*();
        bool operator==(const adjacent_iterator &other) const;
        bool operator!=(const adjacent_iterator &other) const;
    private:
        explicit adjacent_iterator(ProductionList &PL, size_t second);
        ProductionList &pl_;
        size_t second_;
    };
    class indirect_iterator {
        friend class ProductionList;
    public:
        indirect_iterator & operator++();
        Production & operator*();
        bool operator==(const indirect_iterator &other) const;
        bool operator!=(const indirect_iterator &other) const;
    private:
        explicit indirect_iterator(ProductionList &PL, size_t pos);
        ProductionList &pl_;
        size_t i_;
    };
public:
// methods
    void add(Production *P);
    void add_first(Production *P);
    size_t size() const;
    size_t count(Production::Type type);
    ProductionList filter(Production::Type type);
    // adjacent iterator, pair<Production, Production>
    adjacent_iterator adjacent_begin();
    adjacent_iterator adjacent_end();
    // normal iterator
    indirect_iterator begin();
    indirect_iterator end();
    Production & first();
    Production & last();
};

class Ast {
public:
    enum Type { SYM, PROD };

private:
// fields
    std::string name_;
    // type {SYM, PROD}
    Type type_;
    // data for all types
    union {
        Token * symbol_; // SYM
        std::vector<Ast*> * children_; // PROD
    };

public:
    void add_child(Ast &child);
};

// API
#define GM_BEGIN(PL) ProductionList PL
#define GM_ADD(PL, name)                               \
    (PL).add(new Production(#name, Production::PROD)); \
    Production &name = ((PL).last())
#define GM_END(PL)                \
    do                            \
    {                             \
        sanity_check(PL);         \
        compute_FIRST_FOLLOW(PL); \
        print_grammer(PL);        \
    } while (false)

class ProductionBuilder {
public:
    static Production SYM(Token symbol)
    {
        Production sym("SYM", Production::SYM);
        sym.symbol_ = new Token(symbol);
        return std::move(sym);
    }
    static Production CODE(std::function<void()> code)
    {
        Production cod("CODE", Production::CODE);
        cod.code_ = new std::function<void()>(code);
        return std::move(cod);
    }

    static Production AND(Production & P)
    {
        Production pand("AND", Production::AND);
        pand.children_ = new ProductionList;
        pand.children_->add(&P);
        return std::move(pand);
    }
    template <class... TL>
    static Production AND(Production & P, TL & ...PL)
    {
        Production pand = ProductionBuilder::AND(PL...);
        pand.children().add_first(&P);
        return std::move(pand);
    }
    // template <class... TL>
    // static Production AND(Production & P, TL && ...PL)
    // {
    //     Production pand = ProductionBuilder::AND(std::move(PL)...);
    //     pand.children().add_first(&P);
    //     return std::move(pand);
    // }
    // static Production AND(Production && P)
    // {
    //     Production pand("AND", Production::AND);
    //     pand.children_ = new ProductionList;
    //     pand.children_->add(new Production(std::move(P)));
    //     return std::move(pand);
    // }
    // template <class... TL>
    // static Production AND(Production && P, TL ...PL)
    // {
    //     Production pand = ProductionBuilder::AND(PL...);
    //     pand.children().add(new Production(std::move(P)));
    //     return std::move(pand);
    // }

    // static Production OR(Production & P)
    // {
    //     Production por("OR", Production::OR);
    //     por.children_ = new ProductionList;
    //     por.children_->add(&P);
    //     return std::move(por);
    // }
    static Production OR(Production && P)
    {
        Production por("OR", Production::OR);
        por.children_ = new ProductionList;
        por.children_->add(new Production(std::move(P)));
        return std::move(por);
    }
    // template <class... TL>
    // static Production OR(Production & P, TL && ...PL)
    // {
    //     Production por = OR(std::move(PL)...);
    //     por.children().add(&P);
    //     return std::move(por);
    // }
    template <class... TL>
    static Production OR(Production && P, TL && ...PL)
    {
        Production por = OR(std::move(PL)...);
        por.children().add(new Production(std::move(P)));
        return std::move(por);
    }

    static Production OPT(Production && P)
    {
        Production opt("OPT", Production::OPT);
        opt.child_ = new Production(std::move(P));
        return std::move(opt);
    }

    static Production REP(Production && P)
    {
        Production rep("REP", Production::REP);
        rep.child_ = new Production(std::move(P));
        return std::move(rep);
    }
};

// Ast * match(ProductionList & PL, TokenIterator & TL);
// void run(ProductionList &PL, TokenIterator &TL);
Ast * match_run(ProductionList & PL, TokenIterator & TL);
class AstFactory {
public:
    Ast * create(std::string name, Ast::Type type, Token symbol) { return nullptr; }
    Ast * create(std::string name, Ast::Type type) { return nullptr; }
};


// Impl
void sanity_check(ProductionList &PL);
void compute_FIRST_FOLLOW(ProductionList &PL);
Ast * match_run_impl(Production & P, TokenIterator & TL, Ast * AP, AstFactory & factory);
bool match_FIRST(Production &P, Token T);
void print_grammer(ProductionList &PL);
