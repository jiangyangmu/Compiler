#include "parser.h"

#include <cassert>

Production::iterator::iterator() {}
Production::iterator::iterator(Production &root)
{
    next_.push_back(&root);
}

Production::iterator & Production::iterator::operator++()
{
    if (next_.empty())
        return (*this);

    Production *p = next_.front();
    switch (p->type())
    {
        case SYM:
        case CODE:
        case PROD:
            break;
        case AND:
        case OR:
            for (Production &child : p->children())
            {
                next_.push_back(&child);
            }
            break;
        case OPT:
        case REP:
            next_.push_back(&p->child());
            break;
    }
    next_.pop_front();
    return (*this);
}

Production & Production::iterator::operator*()
{
    assert(!next_.empty());
    return *next_.front();
}

bool Production::iterator::operator==(const Production::iterator &other) const
{
    if (next_.size() != other.next_.size())
        return false;
    for (size_t i = 0; i < next_.size(); ++i)
    {
        if (next_[i] != other.next_[i])
            return false;
    }
    return true;
}
bool Production::iterator::operator!=(const Production::iterator &other) const
{
    return !(*this == other);
}

Token & Production::symbol()
{
    assert(type_ == SYM);
    return *symbol_;
}
std::function<void()> & Production::code()
{
    assert(type_ == CODE);
    return *code_;
}
Production & Production::production()
{
    assert(type_ == PROD);
    return *production_;
}
ProductionList & Production::children()
{
    assert(type_ == AND || type_ == OR);
    return *children_;
}
Production & Production::child()
{
    assert(type_ == OPT || type_ == REP);
    return *child_;
}
TokenSet & Production::FIRST()
{
    assert(type_ != CODE);
    return FIRST_;
}
TokenSet & Production::FOLLOW()
{
    assert(type_ != CODE);
    return FOLLOW_;
}
Production::iterator Production::begin()
{
    assert(type_ == PROD);
    return Production::iterator(production());
}
Production::iterator Production::end()
{
    return Production::iterator();
}
std::string DebugString_impl(Production &P)
{
    std::string s;

    switch (P.type())
    {
        case Production::SYM:
            s += '\'';
            s += P.symbol();
            s += '\'';
            break;
        case Production::CODE:
            break;
        case Production::PROD:
            s += P.production().name();
            break;
        case Production::AND:
            s += "(and";
            for (Production & p : P.children())
            {
                s += ' ';
                s += DebugString_impl(p);
            }
            s += ")";
            break;
        case Production::OR:
            s += "(or";
            for (Production & p : P.children())
            {
                s += ' ';
                s += DebugString_impl(p);
            }
            s += ")";
            break;
        case Production::OPT:
            s += "(opt ";
            s += DebugString_impl(P.child());
            s += ")";
            break;
        case Production::REP:
            s += "(rep ";
            s += DebugString_impl(P.child());
            s += ")";
            break;
    }
    return s;
}
std::string Production::DebugString()
{
    return DebugString_impl(production());
}

ProductionList::adjacent_iterator::adjacent_iterator(ProductionList &PL, size_t second)
    : pl_(PL), second_(std::min(second, PL.size()))
{}
ProductionList::adjacent_iterator & ProductionList::adjacent_iterator::operator++()
{
    if (second_ < pl_.size())
        ++second_;
    return (*this);
}
std::pair<Production &, Production &> ProductionList::adjacent_iterator::operator*()
{
    assert(second_ > 0 && second_ < pl_.size());
    return std::pair<Production &, Production &>(*pl_[second_ - 1], *pl_[second_]);
}
bool ProductionList::adjacent_iterator::operator==(const adjacent_iterator &other) const
{
    assert(pl_ == other.pl_);
    return second_ == other.second_;
}
bool ProductionList::adjacent_iterator::operator!=(const adjacent_iterator &other) const
{
    return !(*this == other);
}

ProductionList::indirect_iterator::indirect_iterator(ProductionList &PL, size_t pos)
    : pl_(PL), i_(std::min(pos, PL.size()))
{}
ProductionList::indirect_iterator & ProductionList::indirect_iterator::operator++()
{
    if (i_ < pl_.size())
        ++i_;
    return (*this);
}
Production & ProductionList::indirect_iterator::operator*()
{
    assert(i_ < pl_.size());
    return *pl_[i_];
}
bool ProductionList::indirect_iterator::operator==(const indirect_iterator &other) const
{
    assert(pl_ == other.pl_);
    return i_ == other.i_;
}
bool ProductionList::indirect_iterator::operator!=(const indirect_iterator &other) const
{
    return !(*this == other);
}

void ProductionList::add(Production *P)
{
    assert(P != nullptr);
    push_back(P);
}
void ProductionList::add_first(Production *P)
{
    assert(P != nullptr);
    push_front(P);
}
size_t ProductionList::size() const
{
    return std::deque<Production *>::size();
}
size_t ProductionList::count(Production::Type type)
{
    size_t cnt = 0;
    for (Production & P : (*this))
    {
        if (P.is(type))
            ++cnt;
    }
    return cnt;
}
ProductionList ProductionList::filter(Production::Type type)
{
    ProductionList pl;
    for (Production & P : (*this))
    {
        if (!P.is(type))
            pl.push_back(&P);
    }
    return pl;
}
ProductionList::adjacent_iterator ProductionList::adjacent_begin()
{
    return adjacent_iterator(*this, 1);
}
ProductionList::adjacent_iterator ProductionList::adjacent_end()
{
    return adjacent_iterator(*this, size());
}
ProductionList::indirect_iterator ProductionList::begin()
{
    return indirect_iterator(*this, 0);
}
ProductionList::indirect_iterator ProductionList::end()
{
    return indirect_iterator(*this, size());
}
Production & ProductionList::first()
{
    assert(!empty());
    return *front();
}
Production & ProductionList::last()
{
    assert(!empty());
    return *back();
}

void Ast::add_child(Ast & child)
{
    assert(type_ == PROD);
    if (children_ == nullptr)
    {
        children_ = new std::vector<Ast *>();
    }
    children_->push_back(&child);
}

void sanity_check(ProductionList &PL)
{
    for (Production &root : PL)
    {
        for (Production &P : root)
        {
            switch (P.type())
            {
                case Production::SYM:
                case Production::CODE:
                case Production::PROD:
                    break;
                case Production::AND:
                    CHECK_GT(P.children().size(), P.children().count(Production::CODE));
                    break;
                case Production::OR:
                    CHECK_EQ(0, P.children().count(Production::CODE));
                    break;
                case Production::OPT:
                case Production::REP:
                    CHECK(!P.is(Production::CODE));
                    break;
            }
        }
    }
}

void print_grammer(ProductionList &PL)
{
    for (Production &root : PL)
    {
        std::cout << root.name() << ":\n\tFIRST: ";
        DebugPrint(root.FIRST());
        std::cout << "\n\tFOLLOW: ";
        DebugPrint(root.FOLLOW());
    }
}

void compute_FIRST_FOLLOW(ProductionList &PL)
{
    TopoMap<TokenSet*> D;
    for (Production &root : PL)
    {
        D.add_dependency(&root.production().FIRST(), &root.FIRST());
        D.add_dependency(&root.production().FOLLOW(), &root.FOLLOW());
        for (Production &P : root)
        {
            ProductionList solid_children;
            switch (P.type())
            {
                case Production::SYM:
                    P.FIRST() = {P.symbol()};
                    P.FOLLOW() = {};
                    break;
                case Production::CODE:
                    break;
                case Production::PROD:
                    break;
                case Production::AND:
                    solid_children = P.children().filter(Production::CODE);
                    D.add_dependency(&solid_children.first().FIRST(), &P.FIRST());
                    for (auto adj = solid_children.adjacent_begin(); adj != solid_children.adjacent_end(); ++adj)
                    {
                        std::cout << (*adj).second.name() << ".first -> " << (*adj).first.name() << ".follow" << std::endl;
                        D.add_dependency(&(*adj).second.FIRST(), &(*adj).first.FOLLOW());
                    }
                    break;
                case Production::OR:
                    for (Production &child : P.children())
                    {
                        D.add_dependency(&child.FIRST(), &P.FIRST());
                        D.add_dependency(&P.FOLLOW(), &child.FOLLOW());
                    }
                    break;
                case Production::OPT:
                case Production::REP:
                    D.add_dependency(&P.child().FIRST(), &P.FIRST());
                    D.add_dependency(&P.FOLLOW(), &P.FIRST());
                    break;
            }
        }
    }

    std::vector<TokenSet*> FL = D.sort();
    for (TokenSet *F : FL)
    {
        for (TokenSet *Fd : D.dependents(F))
        {
            Fd->insert(F->begin(), F->end());
        }
    }
}

Ast * match_run_impl(Production &P, TokenIterator &TL, Ast *AP, AstFactory &factory)
{
    Ast * A = nullptr;
    Ast * ret = nullptr;
    switch (P.type())
    {
        case Production::SYM:
            CHECK_EQ(P.symbol(), TL.next());
            A = factory.create(P.name(), Ast::SYM, P.symbol());
            if (AP == nullptr)
            {
                ret = A;
            }
            else
            {
                AP->add_child(*A);
            }
            break;
        case Production::PROD:
            A = factory.create(P.name(), Ast::PROD);
            match_run_impl(P.production(), TL, A, factory);
            if (AP == nullptr)
            {
                ret = A;
            }
            else
            {
                AP->add_child(*A);
            }
            break;
        case Production::CODE:
            P.code()();
            break;
        case Production::AND:
            for (Production &child : P.children())
            {
                match_run_impl(child, TL, AP, factory);
            }
            break;
        case Production::OR:
            for (Production &child : P.children())
            {
                if (match_FIRST(child, TL.peek()))
                {
                    match_run_impl(child, TL, AP, factory);
                    break;
                }
            }
            break;
        case Production::OPT:
            if (match_FIRST(P.child(), TL.peek()))
            {
                match_run_impl(P.child(), TL, AP, factory);
            }
            break;
        case Production::REP:
            while (match_FIRST(P.child(), TL.peek()))
            {
                match_run_impl(P.child(), TL, AP, factory);
            }
            break;
    }
    return ret;
}

bool match_FIRST(Production &P, Token T)
{
    return (P.FIRST().find(T) != P.FIRST().end());
}
